# 🛒 AMZ Extractor - Amazon Product Data Tool

**Professional Amazon product data extraction for Chrome & Microsoft Edge**

Extract product information, prices, reviews, and more from Amazon with just one click. Perfect for affiliate marketers, product researchers, and e-commerce professionals.

## 🚀 Quick Start

1. **Install**: Load the extension in Chrome or Edge (see [Installation Guide](INSTALLATION_GUIDE.md))
2. **Navigate**: Go to any Amazon product or category page
3. **Extract**: Click the extension icon and start extracting data
4. **Export**: Download your data in JSON, CSV, or Excel format

## ✨ Key Features

### 🎯 Single Product Extraction
- Extract complete product data with one click
- Get titles, prices, images, reviews, and specifications
- Works on all Amazon product detail pages

### 📊 Bulk Product Extraction
- Extract 5-500 products from category pages
- Multiple scraping modes (Fast, Detailed, Reviews)
- Real-time progress monitoring with pause/resume

### 🌍 Global Amazon Support
- Works on 19+ Amazon domains worldwide
- US, UK, Germany, Japan, India, and more
- Automatic domain detection

### 📤 Multiple Export Formats
- **JSON**: Complete data structure for developers
- **CSV**: Perfect for Excel and Google Sheets
- **Excel**: Formatted spreadsheets ready for analysis

### ⚡ Advanced Features
- Affiliate tag integration
- Custom extraction delays
- Browser notifications
- Context menu shortcuts

## 🔧 Installation

### Chrome Installation
1. Download the extension folder
2. Go to `chrome://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked" and select the folder

### Edge Installation
1. Download the extension folder
2. Go to `edge://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked" and select the folder

**📋 [Complete Installation Guide](INSTALLATION_GUIDE.md)**

## 📖 Documentation

- **📋 [Installation Guide](INSTALLATION_GUIDE.md)** - Step-by-step setup instructions
- **📚 [User Manual](USER_MANUAL.md)** - Complete usage guide and features
- **🔧 Troubleshooting** - Common issues and solutions

## 🌟 What You Can Extract

### Product Information
- Title, Brand, ASIN, SKU
- Current price, original price, discounts
- Product images and thumbnails
- Product dimensions and weight
- Category and subcategory

### Customer Data
- Average rating and review count
- Recent customer reviews
- Q&A sections
- Bestseller rank

### Availability
- Stock status and quantity
- Shipping information
- Prime eligibility
- Delivery estimates

### Variations
- Available colors, sizes, styles
- Variation pricing
- Option-specific images

## 🎯 Use Cases

### 🛍️ Affiliate Marketing
- Research profitable products
- Monitor price changes
- Build product comparison sites
- Track competitor pricing

### 📈 E-commerce Research
- Market analysis and trends
- Product sourcing for resale
- Competitor product analysis
- Price monitoring and alerts

### 📊 Data Analysis
- Build product databases
- Export to analytics tools
- Create market reports
- Track product performance

## 🔒 Privacy & Security

- **Local Processing**: All data stays in your browser
- **No Data Collection**: We don't collect or store your data
- **Amazon Only**: Extension only works on Amazon websites
- **Secure**: No access to personal accounts or sensitive information

## 🌍 Supported Amazon Domains

| Country | Domain | Supported |
|---------|--------|-----------|
| 🇺🇸 United States | amazon.com | ✅ |
| 🇬🇧 United Kingdom | amazon.co.uk | ✅ |
| 🇩🇪 Germany | amazon.de | ✅ |
| 🇫🇷 France | amazon.fr | ✅ |
| 🇯🇵 Japan | amazon.co.jp | ✅ |
| 🇮🇳 India | amazon.in | ✅ |
| 🇨🇦 Canada | amazon.ca | ✅ |
| 🇦🇺 Australia | amazon.com.au | ✅ |
| And 11 more... | See full list | ✅ |

## 🎛️ Extraction Modes

### 🚀 Fast Mode
- **Speed**: 1-2 seconds per product
- **Data**: Title, Price, Rating, ASIN
- **Best for**: Quick price checks, basic monitoring

### 📋 Detailed Mode ⭐ (Recommended)
- **Speed**: 2-3 seconds per product
- **Data**: Complete product information
- **Best for**: Product research, comprehensive analysis

### 💬 Reviews Mode
- **Speed**: 4-5 seconds per product
- **Data**: Everything + customer reviews
- **Best for**: In-depth market research

## 📞 Support & Help

### Getting Help
- **📚 User Manual**: Complete feature documentation
- **🔧 Troubleshooting**: Common issues and solutions
- **💬 Support**: https://extractor.aiwriterpros.com/support

### System Requirements
- **Chrome**: Version 88 or higher
- **Edge**: Version 88 or higher
- **RAM**: 4GB+ recommended for bulk extraction
- **Internet**: Stable broadband connection

## 🔄 Updates & Changelog

### Version 2.0.0
- ✅ Bulk product extraction
- ✅ Multiple export formats
- ✅ Enhanced error handling
- ✅ Cross-browser compatibility
- ✅ Improved user interface

## 📄 License & Legal

- **Usage**: Free for personal and commercial use
- **Compliance**: Respects Amazon's robots.txt
- **Rate Limiting**: Built-in delays to respect servers
- **Disclaimer**: Use responsibly and follow Amazon's terms

## 🤝 Contributing

We welcome feedback and suggestions! Contact us through our support channels to:
- Report bugs or issues
- Suggest new features
- Share usage feedback
- Request additional Amazon domains

---

## 🎉 Ready to Start?

1. **📥 [Install the Extension](INSTALLATION_GUIDE.md)**
2. **📖 [Read the User Manual](USER_MANUAL.md)**
3. **🚀 Start Extracting Data!**

**Transform your Amazon product research with AMZ Extractor** 🛒✨

---

*Built with ❤️ for affiliate marketers, researchers, and e-commerce professionals*