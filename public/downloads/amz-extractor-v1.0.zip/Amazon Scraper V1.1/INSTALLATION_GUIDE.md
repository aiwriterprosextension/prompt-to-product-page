# AMZ Extractor - Installation Guide

## 🚀 Quick Installation

### For Google Chrome

1. **Download the Extension**
   - Download the `amazon-multi-product-scraper` folder to your computer
   - Make sure all files are extracted and in one folder

2. **Open Chrome Extensions Page**
   - Open Google Chrome
   - Type `chrome://extensions/` in the address bar and press Enter
   - Or go to Chrome Menu (⋮) → More Tools → Extensions

3. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner
   - This allows you to install unpacked extensions

4. **Load the Extension**
   - Click "Load unpacked" button
   - Navigate to and select the `amazon-multi-product-scraper` folder
   - Click "Select Folder"

5. **Verify Installation**
   - You should see "AMZ Extractor" appear in your extensions list
   - The extension icon should appear in your Chrome toolbar
   - If you don't see the icon, click the puzzle piece (🧩) and pin AMZ Extractor

### For Microsoft Edge

1. **Download the Extension**
   - Download the `amazon-multi-product-scraper` folder to your computer
   - Ensure all files are in one folder

2. **Open Edge Extensions Page**
   - Open Microsoft Edge
   - Type `edge://extensions/` in the address bar and press Enter
   - Or go to Edge Menu (⋯) → Extensions

3. **Enable Developer Mode**
   - Toggle "Developer mode" switch on the left sidebar
   - This enables installation of unpacked extensions

4. **Load the Extension**
   - Click "Load unpacked" button
   - Browse to and select the `amazon-multi-product-scraper` folder
   - Click "Select Folder"

5. **Verify Installation**
   - "AMZ Extractor" should appear in your extensions list
   - The extension icon should be visible in your Edge toolbar
   - If not visible, click the extensions menu (🧩) and pin it

## 🔧 Troubleshooting Installation Issues

### Common Problems & Solutions

**Error: "Manifest file is missing or unreadable"**
- Make sure you're selecting the main `amazon-multi-product-scraper` folder
- Don't select subfolders like `images` or individual files
- The folder must contain `manifest.json` in the root

**Error: "Couldn't load icon"**
- Ensure all icon files are present in the `images` folder
- Check that /images/photo1756571214.jpg`, /images/photo1756571215.jpg`, and /images/photo1756571214.jpg` exist
- Re-download the extension if files are missing

**Extension not appearing in toolbar**
- Click the extensions menu (puzzle piece 🧩)
- Find "AMZ Extractor" and click the pin icon
- The extension will now stay visible in your toolbar

**Permission warnings**
- The extension requests permissions to access Amazon websites only
- These permissions are necessary for the extension to work
- Click "Allow" or "Accept" to proceed

## 📱 Browser Compatibility

### Supported Browsers
- ✅ **Google Chrome** (Version 88+)
- ✅ **Microsoft Edge** (Version 88+)
- ✅ **Chromium-based browsers** (Brave, Opera, Vivaldi)

### Unsupported Browsers
- ❌ Firefox (uses different extension format)
- ❌ Safari (different extension system)
- ❌ Internet Explorer (discontinued)

## 🌍 Supported Amazon Domains

The extension works on all major Amazon websites:

- 🇺🇸 Amazon.com (United States)
- 🇨🇦 Amazon.ca (Canada)
- 🇬🇧 Amazon.co.uk (United Kingdom)
- 🇩🇪 Amazon.de (Germany)
- 🇫🇷 Amazon.fr (France)
- 🇪🇸 Amazon.es (Spain)
- 🇮🇹 Amazon.it (Italy)
- 🇯🇵 Amazon.co.jp (Japan)
- 🇮🇳 Amazon.in (India)
- 🇦🇺 Amazon.com.au (Australia)
- 🇲🇽 Amazon.com.mx (Mexico)
- 🇳🇱 Amazon.nl (Netherlands)
- 🇸🇪 Amazon.se (Sweden)
- 🇧🇷 Amazon.com.br (Brazil)
- 🇸🇬 Amazon.sg (Singapore)
- 🇦🇪 Amazon.ae (UAE)
- 🇹🇷 Amazon.com.tr (Turkey)
- 🇵🇱 Amazon.pl (Poland)

## 🔒 Privacy & Security

### What the Extension Does
- Only activates on Amazon websites
- Extracts publicly available product information
- Stores data locally in your browser
- Does not send data to external servers

### What the Extension Does NOT Do
- Access your personal Amazon account
- Store your login credentials
- Track your browsing outside Amazon
- Send data to third parties

## 📞 Getting Help

If you encounter issues during installation:

1. **Check System Requirements**
   - Ensure you're using Chrome 88+ or Edge 88+
   - Verify you have administrator privileges

2. **Restart Your Browser**
   - Close all browser windows
   - Reopen and try installation again

3. **Clear Browser Cache**
   - Go to browser settings
   - Clear browsing data and cache
   - Retry installation

4. **Contact Support**
   - Visit: https://extractor.aiwriterpros.com/support
   - Email support with your browser version and error message

## 🎯 Next Steps

After successful installation:
1. Visit any Amazon product page
2. Click the AMZ Extractor icon in your toolbar
3. Follow the user manual for detailed usage instructions
4. Start extracting product data!

---

**Installation Complete!** 🎉
Ready to start extracting Amazon product data efficiently.