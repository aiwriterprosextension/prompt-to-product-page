// Enhanced Amazon Product Scraper Content Script
console.log('AMZ Extractor content script loaded');

// Cross-browser API compatibility
const extensionAPI = typeof browser !== 'undefined' ? browser : chrome;

// Global state
let isExtracting = false;
let extractionPaused = false;
let extractionStopped = false;
let currentExtractionData = [];

// Message listener
extensionAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Content script received message:', request.action);
  
  switch (request.action) {
    case 'checkPageType':
      handleCheckPageType(sendResponse);
      return true;
    case 'extractSingleProduct':
      handleSingleExtraction(request.options, sendResponse);
      return true;
    case 'startBulkScraping':
      handleBulkExtraction(request.options, sendResponse);
      return true;
    case 'pauseBulkExtraction':
      extractionPaused = true;
      sendResponse({ success: true });
      break;
    case 'resumeBulkExtraction':
      extractionPaused = false;
      sendResponse({ success: true });
      break;
    case 'stopBulkExtraction':
      extractionStopped = true;
      sendResponse({ success: true });
      break;
  }
});

// Check page type and compatibility
function handleCheckPageType(sendResponse) {
  try {
    const pageInfo = {
      isProductPage: isProductPage(),
      isCategoryPage: isCategoryPage(),
      isSearchPage: isSearchPage(),
      productCount: getProductCount(),
      url: window.location.href
    };
    
    console.log('Page info:', pageInfo);
    console.log('Products found:', getProductElements().length);
    sendResponse({ success: true, data: pageInfo });
  } catch (error) {
    console.error('Page type check error:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Check if current page is a product page
function isProductPage() {
  const indicators = [
    document.querySelector('#dp-container'),
    document.querySelector('[data-asin]'),
    document.querySelector('#productTitle'),
    document.querySelector('#ASIN'),
    document.querySelector('.a-price-whole'),
    window.location.pathname.includes('/dp/'),
    window.location.pathname.includes('/gp/product/')
  ];
  
  return indicators.some(indicator => indicator);
}

// Check if current page is a category/listing page
function isCategoryPage() {
  const indicators = [
    document.querySelector('[data-component-type="s-search-result"]'),
    document.querySelector('.s-result-item'),
    document.querySelector('[data-cel-widget="search_result"]'),
    document.querySelector('.sg-col-inner .s-widget-container'),
    document.querySelector('#search'),
    document.querySelector('.s-main-slot'),
    document.querySelector('[data-asin]:not([data-asin=""])'),
    document.querySelector('.s-result-list'),
    document.querySelector('[data-cy="title-recipe-label"]'),
    document.querySelector('.s-search-results')
  ];
  
  return indicators.some(indicator => indicator);
}

// Check if current page is a search page
function isSearchPage() {
  return window.location.pathname.includes('/s/') || 
         window.location.search.includes('field-keywords') ||
         window.location.search.includes('k=') ||
         window.location.pathname.includes('/gp/search/');
}

// Get product count on page with enhanced detection
function getProductCount() {
  const products = getProductElements();
  console.log('Product count detected:', products.length);
  console.log('URL:', window.location.href);
  console.log('Is category page:', isCategoryPage());
  console.log('Is search page:', isSearchPage());
  return products.length;
}

// Get product elements from page with comprehensive selectors
function getProductElements() {
  // Multiple selector strategies for different Amazon layouts
  const selectorSets = [
    // Modern Amazon search results
    '[data-component-type="s-search-result"]',
    
    // Alternative search result selectors
    '.s-result-item[data-asin]:not([data-asin=""])',
    
    // Category page products
    '[data-cel-widget="search_result"]',
    
    // Grid layout products
    '.sg-col-inner .s-widget-container[data-asin]:not([data-asin=""])',
    
    // Best sellers and category pages
    '[data-asin]:not([data-asin=""]):not(.AdHolder)',
    
    // Alternative product containers
    '.s-search-results [data-asin]:not([data-asin=""])',
    
    // Sponsored and regular results
    '.s-main-slot [data-asin]:not([data-asin=""])',
    
    // Product cards
    '.s-result-list [data-asin]:not([data-asin=""])'
  ];
  
  let products = [];
  
  // Try each selector set
  for (const selector of selectorSets) {
    products = document.querySelectorAll(selector);
    console.log(`Selector "${selector}" found ${products.length} products`);
    if (products.length > 0) break;
  }
  
  // Filter out invalid products
  const validProducts = Array.from(products).filter(product => {
    const asin = product.getAttribute('data-asin');
    
    // Skip if no ASIN or invalid ASIN
    if (!asin || asin === '' || asin === 'undefined') return false;
    
    // Skip sponsored ads that don't have proper product data
    if (product.closest('.AdHolder')) return false;
    
    // Skip if it's just a container without actual product info
    const hasTitle = product.querySelector('h3, h2, .a-size-medium, .a-size-base-plus, [data-cy="title-recipe-label"]');
    if (!hasTitle) return false;
    
    return true;
  });
  
  console.log(`Valid products after filtering: ${validProducts.length}`);
  return validProducts;
}

// Handle single product extraction
async function handleSingleExtraction(options, sendResponse) {
  try {
    console.log('Starting single extraction with options:', options);
    
    let productData;
    
    if (isProductPage()) {
      productData = await extractSingleProductData(options);
    } else if (isCategoryPage() || isSearchPage()) {
      const products = getProductElements();
      if (products.length > 0) {
        productData = await extractProductFromElement(products[0], options);
      } else {
        throw new Error('No products found on this page');
      }
    } else {
      throw new Error('Unsupported page type');
    }
    
    console.log('Single extraction completed:', productData);
    sendResponse({ success: true, data: productData });
    
  } catch (error) {
    console.error('Single extraction error:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle bulk extraction
async function handleBulkExtraction(options, sendResponse) {
  try {
    console.log('Starting bulk extraction with options:', options);
    
    if (!isCategoryPage() && !isSearchPage()) {
      throw new Error('Bulk extraction only works on category or search pages');
    }
    
    isExtracting = true;
    extractionPaused = false;
    extractionStopped = false;
    currentExtractionData = [];
    
    const products = getProductElements();
    const totalProducts = Math.min(options.quantity, products.length);
    
    console.log(`Found ${products.length} products, extracting ${totalProducts}`);
    
    if (products.length === 0) {
      throw new Error('No products found on this page. Try refreshing or navigating to a different Amazon page.');
    }
    
    let successful = 0;
    let failed = 0;
    
    for (let i = 0; i < totalProducts && !extractionStopped; i++) {
      // Handle pause
      while (extractionPaused && !extractionStopped) {
        await sleep(100);
      }
      
      if (extractionStopped) break;
      
      try {
        const productData = await extractProductFromElement(products[i], options);
        if (productData) {
          currentExtractionData.push(productData);
          successful++;
        }
      } catch (error) {
        console.error(`Failed to extract product ${i + 1}:`, error);
        failed++;
      }
      
      // Send progress update
      extensionAPI.runtime.sendMessage({
        type: 'bulkProgress',
        data: {
          current: i + 1,
          total: totalProducts,
          successful,
          failed,
          currentProduct: getProductTitle(products[i])
        }
      });
      
      // Delay between requests
      if (i < totalProducts - 1 && !extractionStopped) {
        await sleep(options.delay || 2000);
      }
    }
    
    isExtracting = false;
    
    if (extractionStopped) {
      console.log('Bulk extraction stopped by user');
      sendResponse({ success: false, error: 'Extraction stopped by user' });
    } else {
      console.log(`Bulk extraction completed: ${successful} successful, ${failed} failed`);
      
      // Send completion message
      extensionAPI.runtime.sendMessage({
        type: 'bulkComplete',
        data: currentExtractionData
      });
      
      sendResponse({ success: true, data: currentExtractionData });
    }
    
  } catch (error) {
    console.error('Bulk extraction error:', error);
    isExtracting = false;
    
    extensionAPI.runtime.sendMessage({
      type: 'bulkError',
      error: error.message
    });
    
    sendResponse({ success: false, error: error.message });
  }
}

// Extract data from single product page
async function extractSingleProductData(options) {
  const mode = options.mode || 'detailed';
  const affiliateTag = options.affiliateTag || null;
  const includeAffiliateDetailed = options.includeAffiliateDetailed || false;
  
  // Get raw URL and determine affiliate logic
  const rawUrl = window.location.href;
  let cleanedUrl, affiliateUrl;
  
  // Create clean URL (no affiliate)
  cleanedUrl = cleanAmazonUrl(rawUrl, null, false);
  
  // Create affiliate URL if needed
  if (affiliateTag && (mode === 'affiliate-url' || (mode === 'detailed' && includeAffiliateDetailed))) {
    affiliateUrl = cleanAmazonUrl(rawUrl, affiliateTag, true);
  }
  
  const baseData = {
    title: getElementText('#productTitle, .product-title'),
    asin: getASIN(),
    url: cleanedUrl,
    price: getPrice(),
    rating: getRating(),
    reviewCount: getReviewCount(),
    availability: getAvailability(),
    extractedAt: new Date().toISOString(),
    extractionMode: mode
  };
  
  // URL is already cleaned and affiliate tag added in baseData creation
  
  switch (mode) {
    case 'product-url':
      const productImages = await getProductImagesWithBase64();
      return {
        url: cleanedUrl,
        asin: baseData.asin,
        title: baseData.title,
        images: productImages
      };
      
    case 'affiliate-url':
      const affiliateImages = await getProductImagesWithBase64();
      return {
        url: affiliateUrl || cleanedUrl,
        asin: baseData.asin,
        title: baseData.title,
        images: affiliateImages
      };
      
    case 'links':
      const linkImages = await getProductImagesWithBase64();
      return {
        asin: baseData.asin,
        url: cleanedUrl,
        title: baseData.title,
        images: linkImages
      };
      
    case 'basic':
      const basicImages = await getProductImagesWithBase64();
      return {
        title: baseData.title,
        asin: baseData.asin,
        url: cleanedUrl,
        price: baseData.price,
        rating: baseData.rating,
        reviewCount: baseData.reviewCount,
        brand: getElementText('#bylineInfo, .a-size-base'),
        availability: baseData.availability,
        images: basicImages
      };
      
    case 'detailed':
      const detailedSpecs = getDetailedSpecifications();
      const variants = getProductVariants();
      const reviewsSummary = getReviewsSummary();
      const detailedImages = await getProductImagesWithBase64();
      
      const detailedData = {
        ...baseData,
        brand: getElementText('#bylineInfo, .a-size-base'),
        category: getBreadcrumbs(),
        features: getEnhancedFeatures(),
        specifications: detailedSpecs.specifications,
        productDetails: detailedSpecs.details,
        description: getDescription(),
        images: detailedImages,
        variants,
        reviews: reviewsSummary,
        availability: getAvailability()
      };
      
      // Add affiliate URL if checkbox is checked
      if (includeAffiliateDetailed && affiliateUrl) {
        detailedData.affiliateUrl = affiliateUrl;
      }
      
      return detailedData;
      
    default:
      return baseData;
  }
}

// Extract data from product element in listing with enhanced selectors
async function extractProductFromElement(element, options) {
  const mode = options.mode || 'detailed';
  const affiliateTag = options.affiliateTag || null;
  const includeAffiliateDetailed = options.includeAffiliateDetailed || false;
  
  // Get raw URL and determine affiliate logic
  const rawUrl = getProductUrl(element);
  let cleanedUrl = null;
  let affiliateUrl = null;
  
  if (rawUrl) {
    // Create clean URL (no affiliate)
    cleanedUrl = cleanAmazonUrl(rawUrl, null, false);
    
    // Create affiliate URL if needed
    if (affiliateTag && (mode === 'affiliate-url' || (mode === 'detailed' && includeAffiliateDetailed))) {
      affiliateUrl = cleanAmazonUrl(rawUrl, affiliateTag, true);
    }
  }
  
  const baseData = {
    title: getProductTitle(element),
    asin: element.getAttribute('data-asin'),
    url: cleanedUrl,
    price: getProductPrice(element),
    rating: getProductRating(element),
    reviewCount: getProductReviewCount(element),
    extractedAt: new Date().toISOString(),
    extractionMode: mode
  };
  
  // URL is already cleaned and affiliate tag added in baseData creation
  
  switch (mode) {
    case 'product-url':
      // Get single image with base64 for listing items
      const productImg = getProductImage(element);
      const productImageData = productImg ? [{ url: productImg, base64: await getProductImageData(productImg).catch(() => null) }] : [];
      
      return {
        url: cleanedUrl,
        asin: baseData.asin,
        title: baseData.title,
        images: productImageData
      };
      
    case 'affiliate-url':
      // Get single image with base64 for listing items
      const affiliateImg = getProductImage(element);
      const affiliateImageData = affiliateImg ? [{ url: affiliateImg, base64: await getProductImageData(affiliateImg).catch(() => null) }] : [];
      
      return {
        url: affiliateUrl || cleanedUrl,
        asin: baseData.asin,
        title: baseData.title,
        images: affiliateImageData
      };
      
    case 'links':
      // Get single image with base64 for listing items
      const linkImg = getProductImage(element);
      const linkImageData = linkImg ? [{ url: linkImg, base64: await getProductImageData(linkImg).catch(() => null) }] : [];
      
      return {
        asin: baseData.asin,
        url: cleanedUrl,
        title: baseData.title,
        images: linkImageData
      };
      
    case 'basic':
      // Get single image with base64 for listing items
      const basicImg = getProductImage(element);
      const basicImageData = basicImg ? [{ url: basicImg, base64: await getProductImageData(basicImg).catch(() => null) }] : [];
      
      return {
        title: baseData.title,
        asin: baseData.asin,
        url: cleanedUrl,
        price: baseData.price,
        rating: baseData.rating,
        reviewCount: baseData.reviewCount,
        images: basicImageData,
        brand: getProductBrand(element),
        sponsored: isSponsored(element),
        prime: hasPrime(element)
      };
      
    case 'detailed':
      // Get single image with base64 for listing items
      const detailedImg = getProductImage(element);
      const detailedImageData = detailedImg ? [{ url: detailedImg, base64: await getProductImageData(detailedImg).catch(() => null) }] : [];
      
      const detailedData = {
        ...baseData,
        images: detailedImageData,
        sponsored: isSponsored(element),
        prime: hasPrime(element),
        freeShipping: hasFreeShipping(element),
        brand: getProductBrand(element),
        availability: getProductAvailability(element),
        features: getProductFeatures(element),
        category: getProductCategory(element)
      };
      
      // Add affiliate URL if checkbox is checked
      if (includeAffiliateDetailed && affiliateUrl) {
        detailedData.affiliateUrl = affiliateUrl;
      }
      
      return detailedData;
      
    default:
      return baseData;
  }
}

// Enhanced utility functions for product listings
function getProductTitle(element) {
  const titleSelectors = [
    'h3 a span',
    'h2 a span', 
    '.a-size-medium span',
    '.a-size-base-plus',
    '[data-cy="title-recipe-label"]',
    '.s-size-mini span',
    '.a-link-normal span',
    'h3 span',
    'h2 span'
  ];
  
  for (const selector of titleSelectors) {
    const titleElement = element.querySelector(selector);
    if (titleElement && titleElement.textContent.trim()) {
      return titleElement.textContent.trim();
    }
  }
  
  return 'Unknown Product';
}

function getProductUrl(element) {
  const linkSelectors = [
    'h3 a',
    'h2 a', 
    '.a-link-normal',
    'a[href*="/dp/"]',
    'a[href*="/gp/product/"]'
  ];
  
  for (const selector of linkSelectors) {
    const linkElement = element.querySelector(selector);
    if (linkElement) {
      const href = linkElement.getAttribute('href');
      if (href) {
        // Determine the correct Amazon domain
        let baseUrl = 'https://amazon.com';
        
        // Try to get the domain from the current page
        try {
          const currentDomain = window.location.hostname;
          if (currentDomain.includes('amazon.')) {
            baseUrl = `https://${currentDomain}`;
          }
        } catch (e) {
          // Fallback to amazon.com
        }
        
        return href.startsWith('http') ? href : `${baseUrl}${href}`;
      }
    }
  }
  
  return null;
}

function getProductPrice(element) {
  const priceSelectors = [
    '.a-price .a-offscreen',
    '.a-price-whole',
    '.a-color-price',
    '.a-price-range .a-offscreen'
  ];
  
  for (const selector of priceSelectors) {
    const priceElement = element.querySelector(selector);
    if (priceElement) {
      return cleanPrice(priceElement.textContent);
    }
  }
  
  return null;
}

function getProductRating(element) {
  const ratingSelectors = [
    '.a-icon-alt',
    '[aria-label*="out of 5 stars"]'
  ];
  
  for (const selector of ratingSelectors) {
    const ratingElement = element.querySelector(selector);
    if (ratingElement) {
      const text = ratingElement.textContent || ratingElement.getAttribute('aria-label');
      const match = text.match(/(\d+\.?\d*)/);
      return match ? parseFloat(match[1]) : null;
    }
  }
  
  return null;
}

function getProductReviewCount(element) {
  const reviewSelectors = [
    '.a-size-base',
    '[aria-label*="ratings"]'
  ];
  
  for (const selector of reviewSelectors) {
    const reviewElement = element.querySelector(selector);
    if (reviewElement) {
      const text = reviewElement.textContent || reviewElement.getAttribute('aria-label');
      const match = text.match(/\((\d+)\)|(\d+)\s+rating/);
      return match ? parseInt(match[1] || match[2]) : null;
    }
  }
  
  return null;
}

function getProductImage(element) {
  const imgElement = element.querySelector('img');
  if (imgElement) {
    let src = imgElement.src || imgElement.getAttribute('data-src') || imgElement.getAttribute('data-lazy-src');
    if (src && !src.includes('data:image')) {
      // Convert to high-resolution (1500px) format like utils.js
      return src.replace(/._[^.]+_\.(jpeg|jpg|gif|png|webp|bmp|svg)/i, '._SL1500_.$1');
    }
  }
  return null;
}

function getProductBrand(element) {
  const brandSelectors = [
    '.a-size-base-plus',
    '.s-size-mini',
    '[data-cy="brand-recipe-label"]'
  ];
  
  for (const selector of brandSelectors) {
    const brandElement = element.querySelector(selector);
    if (brandElement && brandElement.textContent.trim()) {
      return brandElement.textContent.trim();
    }
  }
  
  return null;
}

function getProductAvailability(element) {
  const availabilitySelectors = [
    '.a-color-success',
    '.a-color-state',
    '[data-cy="delivery-recipe-label"]'
  ];
  
  for (const selector of availabilitySelectors) {
    const availElement = element.querySelector(selector);
    if (availElement) {
      return availElement.textContent.trim();
    }
  }
  
  return null;
}

function getProductFeatures(element) {
  const features = [];
  const featureElements = element.querySelectorAll('.a-unordered-list .a-list-item, .s-feature-list li');
  
  featureElements.forEach(feature => {
    const text = feature.textContent.trim();
    if (text && text.length > 0) {
      features.push(text);
    }
  });
  
  return features;
}

function getProductCategory(element) {
  const categoryElement = element.querySelector('.a-color-secondary, .s-size-mini');
  return categoryElement ? categoryElement.textContent.trim() : null;
}

function isSponsored(element) {
  return element.querySelector('.s-sponsored-label-text, [data-component-type="sp-sponsored-result"]') !== null;
}

function hasPrime(element) {
  return element.querySelector('.a-icon-prime, [aria-label*="Prime"]') !== null;
}

function hasFreeShipping(element) {
  const text = element.textContent.toLowerCase();
  return text.includes('free shipping') || text.includes('free delivery');
}

// Utility functions for single product pages (unchanged)
function getASIN() {
  const asinElement = document.querySelector('#ASIN');
  if (asinElement) return asinElement.value;
  
  const urlMatch = window.location.pathname.match(/\/dp\/([A-Z0-9]{10})/);
  if (urlMatch) return urlMatch[1];
  
  const dataAsin = document.querySelector('[data-asin]');
  if (dataAsin) return dataAsin.getAttribute('data-asin');
  
  return null;
}

function getPrice() {
  const selectors = [
    '.a-price-whole',
    '.a-offscreen',
    '#priceblock_dealprice',
    '#priceblock_ourprice',
    '.a-price .a-offscreen'
  ];
  
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      return cleanPrice(element.textContent);
    }
  }
  
  return null;
}

function getRating() {
  const ratingElement = document.querySelector('.a-icon-alt, [data-hook="average-star-rating"] .a-icon-alt');
  if (ratingElement) {
    const match = ratingElement.textContent.match(/(\d+\.?\d*)/);
    return match ? parseFloat(match[1]) : null;
  }
  return null;
}

function getReviewCount() {
  const reviewElement = document.querySelector('#acrCustomerReviewText, [data-hook="total-review-count"]');
  if (reviewElement) {
    const match = reviewElement.textContent.match(/(\d+)/);
    return match ? parseInt(match[1]) : null;
  }
  return null;
}

function getAvailability() {
  const availabilityElement = document.querySelector('#availability span, .a-color-success, .a-color-state');
  return availabilityElement ? availabilityElement.textContent.trim() : null;
}

function getBreadcrumbs() {
  const breadcrumbs = document.querySelectorAll('#wayfinding-breadcrumbs_feature_div a');
  return Array.from(breadcrumbs).map(a => a.textContent.trim()).filter(text => text);
}

function getFeatures() {
  const features = document.querySelectorAll('#feature-bullets ul li span, .a-unordered-list .a-list-item');
  return Array.from(features).map(li => li.textContent.trim()).filter(text => text && !text.includes('Make sure'));
}

function getSpecifications() {
  const specs = {};
  const specRows = document.querySelectorAll('#productDetails_techSpec_section_1 tr, .a-keyvalue');
  
  specRows.forEach(row => {
    const key = row.querySelector('td:first-child, .a-color-secondary');
    const value = row.querySelector('td:last-child, .a-color-base');
    if (key && value) {
      specs[key.textContent.trim()] = value.textContent.trim();
    }
  });
  
  return specs;
}

function getDescription() {
  const descElement = document.querySelector('#productDescription p, #aplus');
  return descElement ? descElement.textContent.trim() : null;
}

// Enhanced image extraction functions (inspired by professional affiliate extensions)
// Base64 conversion function for images
async function getProductImageData(imageUrl) {
  try {
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const blob = await response.blob();
    const reader = new FileReader();

    return new Promise((resolve, reject) => {
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error('Failed to fetch and read image data: ', error);
    return null;
  }
}

function getProductImages() {
  const images = [];
  
  // Try multiple image container strategies in order of preference (from utils.js)
  const imageStrategies = [
    // 1. Alternative images container (#altImages)
    () => document.querySelectorAll('#altImages ul li img'),
    // 2. Thumbnail images (#thumbImages) 
    () => document.querySelectorAll('#thumbImages ul li img'),
    // 3. Landing image (#landingImage)
    () => document.querySelectorAll('#landingImage'),
    // 4. Main image (#main-image)
    () => document.querySelectorAll('#main-image'),
    // 5. Image block containers
    () => document.querySelectorAll('#imageBlock img'),
    // 6. Swatch images (color variants)
    () => document.querySelectorAll('img.swatch-image')
  ];
  
  // Try each strategy until we find images
  for (const strategy of imageStrategies) {
    const elements = Array.from(strategy());
    if (elements.length > 0) {
      const filteredImages = elements
        .filter(img => {
          const src = img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy-src');
          return src && 
            !src.includes('360_icon') &&     // Excludes 360° view icons
            !src.includes('.png') &&         // Excludes PNG files (usually icons)
            !src.includes('transparent-pixel') && // Excludes tracking pixels
            !src.includes('/MEDIA') &&       // Excludes media placeholders
            !src.includes('data:image')      // Excludes data URLs
        })
        .slice(0, 5) // Take first 5 images as requested
        .map(img => {
          let src = img.src || img.getAttribute('data-src') || img.getAttribute('data-lazy-src');
          // Convert to high-resolution (1500px) format like utils.js
          return src.replace(/._[^.]+_\.(jpeg|jpg|gif|png|webp|bmp|svg)/i, '._SL1500_.$1');
        });
      
      if (filteredImages.length > 0) {
        images.push(...filteredImages);
        break;
      }
    }
  }
  
  // Fallback: try to get image from hidden input field
  if (images.length === 0) {
    const inputElement = document.querySelector('input#productImageUrl');
    if (inputElement && inputElement.value) {
      const imageUrl = inputElement.value.replace(/._[^.]+_\.(jpeg|jpg|gif|png|webp|bmp|svg)/i, '._SL1500_.$1');
      images.push(imageUrl);
    }
  }
  
  // Remove duplicates and return
  return [...new Set(images)];
}

// Get images with Base64 data
async function getProductImagesWithBase64() {
  const imageUrls = getProductImages();
  const imagesWithBase64 = [];
  
  for (const url of imageUrls) {
    try {
      const base64Data = await getProductImageData(url);
      imagesWithBase64.push({
        url: url,
        base64: base64Data
      });
    } catch (error) {
      console.error('Error getting Base64 for image:', url, error);
      imagesWithBase64.push({
        url: url,
        base64: null
      });
    }
  }
  
  return imagesWithBase64;
}

// Extract comprehensive product specifications
function getDetailedSpecifications() {
  const specs = {};
  const details = [];
  
  // Try multiple specification table selectors
  const specSelectors = [
    '#productDetails_techSpec_section_1 tr',
    '#productDetails_detailBullets_sections1 tr', 
    '#productOverview_feature_div table tr',
    '#productDetails_feature_div table tr',
    '.a-keyvalue tr',
    '.prodDetTable tr'
  ];
  
  specSelectors.forEach(selector => {
    const rows = document.querySelectorAll(selector);
    rows.forEach(row => {
      const cells = row.querySelectorAll('td, th');
      if (cells.length >= 2) {
        const key = cells[0].textContent.trim();
        const value = cells[1].textContent.trim();
        if (key && value && key !== value) {
          specs[key] = value;
        }
      }
    });
  });
  
  // Extract detailed product information tables
  const tables = document.querySelectorAll('#productDetails_feature_div table');
  tables.forEach(table => {
    try {
      const titleElement = table.closest('.a-section')?.querySelector('h1, .a-size-base-plus');
      const title = titleElement ? titleElement.textContent.trim() : 'Product Details';
      
      const attributes = [];
      const rows = table.querySelectorAll('tr');
      
      rows.forEach(row => {
        const cells = row.querySelectorAll('td, th');
        if (cells.length >= 2) {
          let name = cells[0].textContent.trim();
          let value = cells[1].textContent.trim();
          
          // Special handling for Customer Reviews
          if (row.querySelector('#averageCustomerReviews')) {
            const rating = row.querySelector('.a-size-base.a-color-base')?.textContent.trim();
            const ratings = row.querySelector('#acrCustomerReviewText')?.textContent.trim();
            if (rating && ratings) {
              value = `${rating} (${ratings.split(' ')[0]} reviews)`;
            }
          }
          
          if (name && value) {
            attributes.push({ name, value });
          }
        }
      });
      
      if (attributes.length > 0) {
        details.push({ title, attributes });
      }
    } catch (error) {
      console.log('Error extracting table details:', error);
    }
  });
  
  return { specifications: specs, details };
}

// Extract product features and bullet points
function getEnhancedFeatures() {
  const features = [];
  
  // Try multiple feature selectors
  const featureSelectors = [
    '#feature-bullets ul li:not(.a-declarative) span',
    '#feature-bullets .a-list-item span',
    '.a-unordered-list .a-list-item',
    '.feature .a-list-item',
    '#productDescription ul li'
  ];
  
  featureSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      const text = element.textContent.trim();
      if (text && 
          text.length > 10 && 
          !text.includes('Make sure') && 
          !text.includes('See more product details') &&
          !features.includes(text)) {
        features.push(text);
      }
    });
    
    // If we found features, stop looking
    if (features.length > 0) return;
  });
  
  return features;
}

// Extract product variants (colors, sizes, styles)
function getProductVariants() {
  const variants = {
    colors: [],
    sizes: [],
    styles: []
  };
  
  // Extract colors
  const colorElements = document.querySelectorAll('#variation_color_name ul li, #inline-twister-expander-content-color_name ul li');
  colorElements.forEach(element => {
    const colorName = element.getAttribute('title') || element.querySelector('img')?.getAttribute('alt');
    if (colorName && !variants.colors.includes(colorName)) {
      variants.colors.push(colorName);
    }
  });
  
  // Extract sizes
  const sizeElements = document.querySelectorAll('#variation_size_name ul li');
  sizeElements.forEach(element => {
    const sizeName = element.getAttribute('title');
    if (sizeName && !variants.sizes.includes(sizeName)) {
      variants.sizes.push(sizeName);
    }
  });
  
  // Extract styles
  const styleElements = document.querySelectorAll('#inline-twister-row-style_name .swatch-title-text, #variation_style_name ul li');
  styleElements.forEach(element => {
    const styleName = element.textContent.trim() || element.getAttribute('title');
    if (styleName && !variants.styles.includes(styleName)) {
      variants.styles.push(styleName);
    }
  });
  
  return variants;
}

// Extract customer reviews summary
function getReviewsSummary() {
  const reviews = {
    averageRating: null,
    totalReviews: null,
    ratingBreakdown: {}
  };
  
  // Get average rating
  const avgRatingElement = document.querySelector('#averageCustomerReviews .a-size-base.a-color-base, .a-icon-alt');
  if (avgRatingElement) {
    const ratingText = avgRatingElement.textContent || avgRatingElement.getAttribute('title') || '';
    const ratingMatch = ratingText.match(/(\d+\.?\d*)/); 
    if (ratingMatch) {
      reviews.averageRating = parseFloat(ratingMatch[1]);
    }
  }
  
  // Get total reviews count
  const totalReviewsElement = document.querySelector('#acrCustomerReviewText, [data-hook="total-review-count"]');
  if (totalReviewsElement) {
    const reviewText = totalReviewsElement.textContent;
    const reviewMatch = reviewText.match(/([\d,]+)/);
    if (reviewMatch) {
      reviews.totalReviews = parseInt(reviewMatch[1].replace(/,/g, ''));
    }
  }
  
  // Get rating breakdown if available
  const ratingBars = document.querySelectorAll('#histogramTable tr');
  ratingBars.forEach(row => {
    const starElement = row.querySelector('.a-size-base');
    const percentElement = row.querySelector('.a-size-base.a-color-secondary');
    
    if (starElement && percentElement) {
      const stars = starElement.textContent.trim();
      const percent = percentElement.textContent.trim();
      reviews.ratingBreakdown[stars] = percent;
    }
  });
  
  return reviews;
}

async function getTopReviews() {
  const reviews = [];
  const reviewElements = document.querySelectorAll('[data-hook="review"]');
  
  reviewElements.forEach((review, index) => {
    if (index < 5) { // Get top 5 reviews
      const rating = review.querySelector('.a-icon-alt');
      const text = review.querySelector('[data-hook="review-body"] span');
      const author = review.querySelector('.a-profile-name');
      
      if (rating && text) {
        reviews.push({
          rating: rating.textContent.match(/(\d+\.?\d*)/)?.[1] || null,
          text: text.textContent.trim(),
          author: author ? author.textContent.trim() : 'Anonymous'
        });
      }
    }
  });
  
  return reviews;
}

function getVariants() {
  const variants = [];
  const variantElements = document.querySelectorAll('#variation_color_name li, #variation_size_name li');
  
  variantElements.forEach(variant => {
    const title = variant.getAttribute('title') || variant.textContent.trim();
    if (title) variants.push(title);
  });
  
  return variants;
}

// Helper functions
function getElementText(selector) {
  const element = document.querySelector(selector);
  return element ? element.textContent.trim() : null;
}

function cleanPrice(priceText) {
  if (!priceText) return null;
  const cleaned = priceText.replace(/[^\d.,]/g, '');
  return cleaned || null;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Extract ASIN from Amazon URL
function extractASINFromUrl(url) {
  if (!url) return null;
  
  try {
    // Handle different URL formats
    const urlPatterns = [
      /\/dp\/([A-Z0-9]{10})(?:\/|\?|$)/i,        // /dp/ASIN
      /\/gp\/product\/([A-Z0-9]{10})(?:\/|\?|$)/i,  // /gp/product/ASIN
      /\/product\/([A-Z0-9]{10})(?:\/|\?|$)/i,   // /product/ASIN
      /[?&]asin=([A-Z0-9]{10})(?:&|$)/i,       // ?asin=ASIN or &asin=ASIN
      /\/([A-Z0-9]{10})(?:\/ref=|\/\?|\/|\?|$)/i // Direct ASIN in path
    ];
    
    for (const pattern of urlPatterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error extracting ASIN from URL:', error);
    return null;
  }
}

// Clean Amazon URL with smart affiliate logic
function cleanAmazonUrl(url, affiliateTag = null, forceAffiliate = false) {
  if (!url) return url;
  
  try {
    // Extract ASIN first
    const asin = extractASINFromUrl(url);
    if (!asin) {
      console.warn('Could not extract ASIN from URL:', url);
      return url; // Return original if can't extract ASIN
    }
    
    // Determine the Amazon domain from the original URL
    const urlObj = new URL(url);
    const domain = urlObj.hostname;
    
    // Create clean URL
    let cleanUrl = `https://${domain}/dp/${asin}`;
    
    // Add affiliate tag if provided and conditions are met
    if (affiliateTag && affiliateTag.trim() !== '' && forceAffiliate) {
      cleanUrl += `?tag=${encodeURIComponent(affiliateTag.trim())}`;
    }
    
    console.log(`Cleaned URL: ${url} -> ${cleanUrl}`);
    return cleanUrl;
    
  } catch (error) {
    console.error('Error cleaning Amazon URL:', error);
    return url; // Return original URL if cleaning fails
  }
}

// Add affiliate tag to URL (updated to use clean URL function)
function addAffiliateTag(url, affiliateTag) {
  if (!url || !affiliateTag) return cleanAmazonUrl(url);
  
  return cleanAmazonUrl(url, affiliateTag);
}

console.log('AMZ Extractor content script initialized with URL cleaning functionality');