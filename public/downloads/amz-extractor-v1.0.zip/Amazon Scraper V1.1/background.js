// Enhanced background service worker with cross-browser compatibility
console.log('AMZ Extractor background script loaded');

// Cross-browser API compatibility
const extensionAPI = typeof browser !== 'undefined' ? browser : chrome;

// Browser detection
const isEdge = navigator.userAgent?.includes('Edg/') || false;
const browserName = isEdge ? 'Edge' : 'Chrome';

console.log(`Background script running on ${browserName}`);

// Extension installation and update handling
extensionAPI.runtime.onInstalled.addListener((details) => {
  console.log('Extension installed/updated:', details);
  
  if (details.reason === 'install') {
    // First time installation
    console.log('First time installation detected');
    
    // Set default settings
    extensionAPI.storage.local.set({
      defaultMode: 'detailed',
      defaultDelay: '2000',
      installDate: Date.now(),
      browserName: browserName
    });
    
    // Create context menu (optional)
    createContextMenu();
  }
  
  if (details.reason === 'update') {
    console.log('Extension updated from version:', details.previousVersion);
    handleVersionUpdate(details.previousVersion);
  }
});

// Create context menu for quick access
function createContextMenu() {
  try {
    extensionAPI.contextMenus.create({
      id: 'extract-product-data',
      title: 'Extract Amazon Product Data',
      contexts: ['page'],
      documentUrlPatterns: [
        'https://*.amazon.com/*',
        'https://*.amazon.ca/*',
        'https://*.amazon.co.uk/*',
        'https://*.amazon.de/*',
        'https://*.amazon.fr/*',
        'https://*.amazon.es/*',
        'https://*.amazon.it/*',
        'https://*.amazon.co.jp/*',
        'https://*.amazon.in/*',
        'https://*.amazon.com.au/*',
        'https://*.amazon.com.mx/*',
        'https://*.amazon.nl/*',
        'https://*.amazon.se/*',
        'https://*.amazon.com.br/*',
        'https://*.amazon.sg/*',
        'https://*.amazon.ae/*',
        'https://*.amazon.com.tr/*',
        'https://*.amazon.pl/*'
      ]
    });
    
    console.log('Context menu created successfully');
  } catch (error) {
    console.error('Error creating context menu:', error);
  }
}

// Handle context menu clicks
extensionAPI.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'extract-product-data') {
    console.log('Context menu clicked, extracting product data');
    
    extensionAPI.tabs.sendMessage(tab.id, { 
      action: 'extractProductData',
      mode: 'detailed'
    }).then(response => {
      if (response && response.success) {
        console.log('Product data extracted via context menu');
        showNotification('Product data extracted successfully!', 'success');
        downloadProductData(response.productData);
      } else {
        console.error('Failed to extract product data:', response?.error);
        showNotification('Failed to extract product data', 'error');
      }
    }).catch(error => {
      console.error('Error extracting product data:', error);
      showNotification('Error extracting product data', 'error');
    });
  }
});

// Handle messages from popup and content scripts
extensionAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message.action);
  
  if (message.action === 'startBulkScraping') {
    handleBulkScrapingStart(message, sender);
    sendResponse({ success: true });
  }
  
  if (message.action === 'getBrowserInfo') {
    sendResponse({
      browserName: browserName,
      isEdge: isEdge,
      version: extensionAPI.runtime.getManifest().version
    });
  }
  
  if (message.action === 'downloadData') {
    downloadData(message.data, message.filename, message.format);
    sendResponse({ success: true });
  }
  
  return true;
});

// Handle bulk scraping coordination
async function handleBulkScrapingStart(message, sender) {
  console.log('Starting bulk scraping coordination:', message.config);
  
  const { config, productUrls, browserInfo } = message;
  
  try {
    await extensionAPI.storage.local.set({
      bulkSession: {
        startTime: Date.now(),
        config: config,
        productUrls: productUrls,
        browserInfo: browserInfo,
        tabId: sender.tab.id
      }
    });
    
    showNotification(`Starting bulk extraction of ${productUrls.length} products`, 'info');
    monitorBulkProgress(sender.tab.id);
    
  } catch (error) {
    console.error('Error handling bulk scraping start:', error);
  }
}

// Monitor bulk scraping progress
async function monitorBulkProgress(tabId) {
  const progressInterval = setInterval(async () => {
    try {
      const response = await extensionAPI.tabs.sendMessage(tabId, { 
        action: 'getBulkStatus' 
      });
      
      if (!response || !response.isRunning) {
        clearInterval(progressInterval);
        
        if (response && response.state && response.state.extractedData.length > 0) {
          showNotification(
            `Bulk extraction completed! ${response.state.stats.successful} products extracted.`,
            'success'
          );
        }
        
        extensionAPI.storage.local.remove(['bulkSession']);
        return;
      }
      
      const { stats } = response.state;
      const progress = stats.total > 0 ? Math.round(((stats.successful + stats.failed) / stats.total) * 100) : 0;
      
      extensionAPI.action.setBadgeText({
        text: `${progress}%`,
        tabId: tabId
      });
      
      extensionAPI.action.setBadgeBackgroundColor({
        color: progress === 100 ? '#34a853' : '#1a73e8'
      });
      
    } catch (error) {
      console.error('Error monitoring bulk progress:', error);
      clearInterval(progressInterval);
    }
  }, 2000);
}

// Notification system
function showNotification(message, type = 'info') {
  const notificationId = `amz-extractor-${Date.now()}`;
  
  const notificationOptions = {
    type: 'basic',
    iconUrl: '/images/notificationicon.jpg',
    title: 'AMZ Extractor',
    message: message
  };
  
  try {
    extensionAPI.notifications.create(notificationId, notificationOptions);
    
    setTimeout(() => {
      extensionAPI.notifications.clear(notificationId);
    }, 5000);
    
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

// Data download helper
function downloadData(data, filename, format) {
  let content, mimeType;
  
  switch (format) {
    case 'json':
      content = JSON.stringify(data, null, 2);
      mimeType = 'application/json';
      break;
      
    case 'csv':
      content = convertToCSV(data);
      mimeType = 'text/csv';
      break;
      
    default:
      console.error('Unsupported download format:', format);
      return;
  }
  
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  
  extensionAPI.downloads.download({
    url: url,
    filename: filename,
    saveAs: true
  });
}

// Auto-download single product data
function downloadProductData(productData) {
  const filename = `amazon-product-${productData.productASIN || Date.now()}.json`;
  downloadData(productData, filename, 'json');
}

// CSV conversion utility
function convertToCSV(data) {
  if (!Array.isArray(data)) {
    data = [data];
  }
  
  if (!data.length) return '';
  
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value || '';
      }).join(',')
    )
  ].join('\n');
  
  return csvContent;
}

// Handle version updates
function handleVersionUpdate(previousVersion) {
  console.log(`Updating from version ${previousVersion}`);
}

// Tab management
extensionAPI.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('amazon.')) {
    extensionAPI.action.setBadgeText({ text: '', tabId: tabId });
  }
});