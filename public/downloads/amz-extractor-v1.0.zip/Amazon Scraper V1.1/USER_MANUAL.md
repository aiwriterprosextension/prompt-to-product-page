# AMZ Extractor - User Manual

## 📖 Table of Contents
1. [Getting Started](#getting-started)
2. [Single Product Extraction](#single-product-extraction)
3. [Bulk Product Extraction](#bulk-product-extraction)
4. [Export Options](#export-options)
5. [Advanced Features](#advanced-features)
6. [Tips & Best Practices](#tips--best-practices)
7. [Troubleshooting](#troubleshooting)

## 🚀 Getting Started

### First Time Setup
1. **Install the Extension** (see Installation Guide)
2. **Navigate to Amazon** - Go to any Amazon website
3. **Click Extension Icon** - Look for AMZ Extractor in your toolbar
4. **Grant Permissions** - Allow access when prompted

### Understanding the Interface
- **Green Status**: Ready to extract data
- **Blue Status**: Extraction in progress
- **Red Status**: Error or incompatible page
- **Gray Status**: Not on Amazon website

## 🎯 Single Product Extraction

### How to Extract Single Product Data

1. **Navigate to Product Page**
   - Go to any Amazon product detail page
   - URL should contain `/dp/` or `/gp/product/`

2. **Open Extension**
   - Click the AMZ Extractor icon
   - You'll see "Ready to extract product data"

3. **Extract Data**
   - Click "Extract Product Data" button
   - Wait for extraction to complete (usually 2-5 seconds)

4. **View Results**
   - Success message will appear
   - Data is ready for export

### What Data is Extracted?
- **Basic Info**: Title, Price, ASIN, Brand
- **Images**: Main product images and thumbnails
- **Details**: Product dimensions, weight, features
- **Reviews**: Rating, review count, recent reviews
- **Availability**: Stock status, shipping info
- **Variations**: Colors, sizes, styles available

## 📊 Bulk Product Extraction

### Setting Up Bulk Extraction

1. **Navigate to Category/Search Page**
   - Go to Amazon search results
   - Browse category pages
   - Visit best sellers lists

2. **Open Extension**
   - Click AMZ Extractor icon
   - Switch to "Bulk Product Extraction" mode

3. **Configure Settings**
   - **Products to Scrape**: Choose 5-500 products
   - **Scraping Mode**: Select extraction depth
   - **Delay**: Set time between requests
   - **Affiliate Tag**: Add your affiliate ID (optional)

### Scraping Modes Explained

#### 🚀 Fast Mode
- **Speed**: Fastest extraction
- **Data**: Title, Price, Rating, ASIN
- **Use Case**: Quick price monitoring
- **Time**: ~1 second per product

#### 📋 Detailed Mode (Recommended)
- **Speed**: Moderate extraction
- **Data**: Full product information
- **Use Case**: Comprehensive product research
- **Time**: ~2-3 seconds per product

#### 💬 Reviews Mode
- **Speed**: Slowest but most complete
- **Data**: Everything + customer reviews
- **Use Case**: In-depth market analysis
- **Time**: ~4-5 seconds per product

### Delay Settings

| Delay | Speed | Risk Level | Recommendation |
|-------|-------|------------|----------------|
| 1 sec | Fastest | High | Not recommended |
| 2 sec | Fast | Low | **Recommended** |
| 3 sec | Moderate | Very Low | Safe choice |
| 4-5 sec | Slow | Minimal | Conservative |

### Running Bulk Extraction

1. **Start Extraction**
   - Click "Start Bulk Extraction"
   - Progress bar will appear

2. **Monitor Progress**
   - View real-time statistics
   - See current product being processed
   - Track success/failure rates

3. **Control Options**
   - **Pause**: Temporarily stop extraction
   - **Resume**: Continue from where you left off
   - **Stop**: End extraction completely

## 📤 Export Options

### Available Formats

#### JSON Export
- **Best for**: Developers, API integration
- **Contains**: Complete data structure
- **File size**: Largest but most detailed

#### CSV Export
- **Best for**: Excel, Google Sheets
- **Contains**: Tabular data format
- **File size**: Medium, good balance

#### Excel Export
- **Best for**: Advanced spreadsheet analysis
- **Contains**: Formatted tables with headers
- **File size**: Optimized for Excel

### Export Methods

1. **Copy to Clipboard**
   - Instant copying for small datasets
   - Paste directly into other applications

2. **Download Files**
   - Save files to your computer
   - Choose location and filename

3. **Preview Data**
   - View extracted data before export
   - Verify accuracy and completeness

## ⚡ Advanced Features

### Affiliate Integration
- Add your Amazon affiliate tag
- Automatically appends to all product URLs
- Earn commissions from extracted links

### Context Menu
- Right-click on Amazon pages
- Quick "Extract Product Data" option
- Works without opening extension popup

### Browser Notifications
- Real-time extraction updates
- Completion notifications
- Error alerts and warnings

### Data Persistence
- Extracted data saved locally
- Survives browser restarts
- Access previous extractions

## 💡 Tips & Best Practices

### Maximizing Success Rate

1. **Use Recommended Delays**
   - 2-3 seconds between requests
   - Respects Amazon's servers
   - Reduces chance of blocking

2. **Choose Appropriate Mode**
   - Fast mode for price monitoring
   - Detailed mode for research
   - Reviews mode for analysis

3. **Monitor Progress**
   - Watch for error patterns
   - Pause if too many failures
   - Adjust settings if needed

### Avoiding Issues

1. **Don't Rush**
   - Slower is more reliable
   - Quality over quantity
   - Patience prevents problems

2. **Respect Limits**
   - Don't extract thousands at once
   - Take breaks between sessions
   - Use reasonable quantities

3. **Check Results**
   - Verify data accuracy
   - Review failed extractions
   - Re-run if necessary

### Optimal Workflows

#### For Product Research
1. Search for product category
2. Use Detailed Mode with 2-second delay
3. Extract 20-50 products
4. Export to Excel for analysis

#### For Price Monitoring
1. Bookmark product pages
2. Use Fast Mode with 1-second delay
3. Extract 5-10 products regularly
4. Export to CSV for tracking

#### For Market Analysis
1. Browse category pages
2. Use Reviews Mode with 3-second delay
3. Extract 10-30 products
4. Export to JSON for detailed analysis

## 🔧 Troubleshooting

### Common Issues & Solutions

#### "Not on Amazon page" Error
- **Problem**: Extension not detecting Amazon
- **Solution**: Ensure URL contains "amazon" domain
- **Check**: Verify you're on supported Amazon site

#### Extraction Fails or Stops
- **Problem**: Network issues or rate limiting
- **Solution**: Increase delay settings
- **Try**: Pause and resume after a few minutes

#### Missing Product Data
- **Problem**: Some fields are empty
- **Solution**: Product page may not have all data
- **Normal**: Not all products have complete information

#### Slow Performance
- **Problem**: Extraction taking too long
- **Solution**: Use Fast Mode or increase delay
- **Check**: Internet connection speed

#### Export Not Working
- **Problem**: Download or copy fails
- **Solution**: Check browser permissions
- **Try**: Use different export format

### Error Messages Explained

| Error | Meaning | Solution |
|-------|---------|----------|
| "Page not supported" | Not on Amazon product/category page | Navigate to valid Amazon page |
| "No products found" | No extractable products on page | Try different Amazon page |
| "Rate limited" | Too many requests too quickly | Increase delay settings |
| "Network error" | Connection issues | Check internet connection |
| "Parse error" | Data extraction failed | Refresh page and retry |

### Getting Additional Help

1. **Check Browser Console**
   - Press F12 → Console tab
   - Look for error messages
   - Include in support requests

2. **Update Extension**
   - Download latest version
   - Reinstall if necessary
   - Check for compatibility updates

3. **Contact Support**
   - Visit: https://extractor.aiwriterpros.com/support
   - Include browser version and error details
   - Provide screenshot if possible

## 📈 Performance Guidelines

### Recommended Limits
- **Single Session**: 100-200 products maximum
- **Daily Usage**: 500-1000 products total
- **Concurrent Tabs**: Use only one tab at a time

### System Requirements
- **RAM**: 4GB+ recommended for bulk extraction
- **CPU**: Modern processor for smooth operation
- **Internet**: Stable broadband connection

### Browser Optimization
- Close unnecessary tabs
- Disable other extensions temporarily
- Clear cache periodically

---

## 🎉 Congratulations!

You're now ready to efficiently extract Amazon product data using AMZ Extractor. Start with small batches to get familiar with the interface, then scale up to larger extractions as needed.

**Happy Extracting!** 📊✨

---

*For technical support, feature requests, or questions, visit our support page or contact our team.*