// Enhanced popup script with cross-browser compatibility
console.log('AMZ Extractor popup loaded');

// Cross-browser API compatibility
const extensionAPI = typeof browser !== 'undefined' ? browser : chrome;

// Global state
let currentPageInfo = null;
let bulkExtractionData = [];
let singleExtractionData = null;
let isExtracting = false;

// DOM elements
const elements = {
  browserInfo: document.getElementById('browser-info'),
  browserIcon: document.getElementById('browser-icon'),
  browserText: document.getElementById('browser-text'),
  singleSection: document.getElementById('single-section'),
  bulkSection: document.getElementById('bulk-section'),
  status: document.getElementById('status'),
  loading: document.getElementById('loading'),
  notAmazon: document.getElementById('not-amazon'),
  ready: document.getElementById('ready'),
  success: document.getElementById('success'),
  extractBtn: document.getElementById('extract-btn'),
  productsFound: document.getElementById('products-found'),
  quantitySelect: document.getElementById('quantity-select'),
  customQuantity: document.getElementById('custom-quantity'),
  scrapingMode: document.getElementById('scraping-mode'),
  modeDescription: document.getElementById('mode-description'),
  delaySelect: document.getElementById('delay-select'),
  affiliateTag: document.getElementById('affiliate-tag'),
  includeAffiliateDetailed: document.getElementById('include-affiliate-detailed'),
  bulkProgress: document.getElementById('bulk-progress'),
  progressFill: document.getElementById('progress-fill'),
  progressText: document.getElementById('progress-text'),
  progressPercentage: document.getElementById('progress-percentage'),
  currentProduct: document.getElementById('current-product'),
  successfulCount: document.getElementById('successful-count'),
  failedCount: document.getElementById('failed-count'),
  startBulk: document.getElementById('start-bulk'),
  controlButtons: document.getElementById('control-buttons'),
  pauseBulk: document.getElementById('pause-bulk'),
  resumeBulk: document.getElementById('resume-bulk'),
  stopBulk: document.getElementById('stop-bulk'),
  bulkExport: document.getElementById('bulk-export'),
  singleTab: document.getElementById('single-tab'),
  bulkTab: document.getElementById('bulk-tab'),
  // Single product export buttons
  viewData: document.getElementById('view-data'),
  copyJson: document.getElementById('copy-json'),
  downloadCsv: document.getElementById('download-csv'),
  downloadExcel: document.getElementById('download-excel'),
  downloadJson: document.getElementById('download-json'),
  // Bulk export buttons
  bulkViewData: document.getElementById('bulk-view-data'),
  bulkCopyJson: document.getElementById('bulk-copy-json'),
  bulkDownloadCsv: document.getElementById('bulk-download-csv'),
  bulkDownloadExcel: document.getElementById('bulk-download-excel'),
  bulkDownloadJson: document.getElementById('bulk-download-json'),
  // Modal elements
  dataModal: document.getElementById('data-modal'),
  closeModal: document.getElementById('close-modal'),
  dataDisplay: document.getElementById('data-display'),
  modalCopy: document.getElementById('modal-copy'),
  modalDownload: document.getElementById('modal-download'),
  // Dark mode
  darkModeSwitch: document.getElementById('dark-mode-switch')
};

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  console.log('Popup DOM loaded, initializing...');
  
  try {
    initializeBrowserInfo();
    initializeTabs();
    initializeModeDescriptions();
    initializeQuantitySelector();
    initializeCollapsibleSections();
    initializeDarkMode();
    initializeModal();
    
    // Get current tab info
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      await checkPageStatus(tab);
      // Initialize the bulk section with current page info
      if (currentPageInfo) {
        elements.productsFound.textContent = `${currentPageInfo.productCount || 0} products found`;
      }
    }
    
    // Set up event listeners
    setupEventListeners();
    
  } catch (error) {
    console.error('Popup initialization error:', error);
    showError('Failed to initialize extension');
  }
});

// Browser detection and display
function initializeBrowserInfo() {
  const isEdge = navigator.userAgent.includes('Edg/');
  if (isEdge) {
    elements.browserIcon.textContent = '🔷';
    elements.browserText.textContent = 'Running on Microsoft Edge';
  } else {
    elements.browserIcon.textContent = '🔵';
    elements.browserText.textContent = 'Running on Google Chrome';
  }
}

// Tab switching functionality
function initializeTabs() {
  elements.singleTab.addEventListener('click', () => switchTab('single'));
  elements.bulkTab.addEventListener('click', () => switchTab('bulk'));
}

function switchTab(tab) {
  if (tab === 'single') {
    elements.singleSection.classList.remove('hidden');
    elements.bulkSection.classList.add('hidden');
    elements.singleTab.classList.add('active');
    elements.bulkTab.classList.remove('active');
  } else {
    elements.singleSection.classList.add('hidden');
    elements.bulkSection.classList.remove('hidden');
    elements.singleTab.classList.remove('active');
    elements.bulkTab.classList.add('active');
    // Force a re-check of the page status when switching to bulk tab
    if (currentPageInfo) {
      console.log('Switching to bulk tab, current page info:', currentPageInfo);
      // Re-check page status to ensure fresh data
      recheckPageStatus();
    } else {
      // If no page info, try to get it
      recheckPageStatus();
    }
    checkBulkCompatibility();
  }
}

// Mode description updates
function initializeModeDescriptions() {
  const descriptions = {
    'product-url': 'Extracts clean product URLs with Base64 images - fastest option',
    'affiliate-url': 'Extracts affiliate URLs with Base64 images using your affiliate tag',
    links: 'Extracts clean product links, ASINs, and Base64 images - fast option',
    basic: 'Enhanced data: title, price, rating, brand, Prime status, Base64 images',
    detailed: 'Comprehensive extraction: specifications, variants, reviews, Base64 images, features'
  };
  
  elements.scrapingMode.addEventListener('change', (e) => {
    elements.modeDescription.textContent = descriptions[e.target.value];
  });
  
  // Set initial description
  elements.modeDescription.textContent = descriptions[elements.scrapingMode.value];
}

// Quantity selector handling
function initializeQuantitySelector() {
  elements.quantitySelect.addEventListener('change', (e) => {
    if (e.target.value === 'custom') {
      elements.customQuantity.classList.remove('hidden');
      elements.customQuantity.focus();
    } else {
      elements.customQuantity.classList.add('hidden');
    }
  });
  
  // Enforce 100 product limit on custom input
  elements.customQuantity.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    if (value > 100) {
      e.target.value = 100;
      showNotification('Maximum 100 products allowed for bulk extraction', 'info');
    }
  });
}

// Collapsible sections
function initializeCollapsibleSections() {
  const collapsibles = document.querySelectorAll('.collapsible');
  collapsibles.forEach(collapsible => {
    const header = collapsible.querySelector('.collapsible-header');
    header.addEventListener('click', () => {
      collapsible.classList.toggle('collapsed');
    });
  });
}

// Modal functionality
function initializeModal() {
  elements.closeModal.addEventListener('click', () => {
    elements.dataModal.classList.add('hidden');
  });
  
  elements.dataModal.addEventListener('click', (e) => {
    if (e.target === elements.dataModal) {
      elements.dataModal.classList.add('hidden');
    }
  });
}

// Dark Mode
function initializeDarkMode() {
  // Load saved preference
  extensionAPI.storage.local.get('darkMode', (data) => {
    if (data.darkMode) {
      document.body.classList.add('dark-mode');
      elements.darkModeSwitch.checked = true;
    }
  });

  // Toggle on switch change
  elements.darkModeSwitch.addEventListener('change', () => {
    if (elements.darkModeSwitch.checked) {
      document.body.classList.add('dark-mode');
      extensionAPI.storage.local.set({ darkMode: true });
    } else {
      document.body.classList.remove('dark-mode');
      extensionAPI.storage.local.set({ darkMode: false });
    }
  });
}

// Check page status with enhanced Amazon detection
async function checkPageStatus(tab) {
  try {
    if (!isAmazonDomain(tab.url)) {
      showNotAmazonPage();
      return;
    }
    
    // Send message to content script to check page type
    const response = await extensionAPI.tabs.sendMessage(tab.id, { 
      action: 'checkPageType' 
    });
    
    if (response && response.success) {
      currentPageInfo = response.data;
      
      if (response.data.isProductPage) {
        showReadyState();
      } else if (response.data.isCategoryPage) {
        // Update products found display for both single and bulk sections
        elements.productsFound.textContent = `${response.data.productCount || 0} products found`;
        showReadyState();
        // Also update bulk compatibility if bulk tab is active
        if (elements.bulkSection.classList.contains('hidden') === false) {
          checkBulkCompatibility();
        }
      } else {
        showNotAmazonPage();
      }
    } else {
      showNotAmazonPage();
    }
    
  } catch (error) {
    console.error('Page status check error:', error);
    showNotAmazonPage();
  }
}

// Enhanced Amazon domain detection with comprehensive international support
function isAmazonDomain(url) {
  const amazonDomains = [
    // Major markets
    'amazon.com',     // United States
    'amazon.ca',      // Canada
    'amazon.com.mx',  // Mexico
    'amazon.co.uk',   // United Kingdom
    'amazon.de',      // Germany
    'amazon.fr',      // France
    'amazon.es',      // Spain
    'amazon.it',      // Italy
    'amazon.in',      // India
    'amazon.co.jp',   // Japan
    'amazon.com.au',  // Australia
    'amazon.com.br',  // Brazil
    'amazon.nl',      // Netherlands
    'amazon.se',      // Sweden
    'amazon.pl',      // Poland
    'amazon.sg',      // Singapore
    'amazon.ae',      // United Arab Emirates
    'amazon.com.tr',  // Turkey
    'amazon.eg',      // Egypt
    'amazon.sa'       // Saudi Arabia
  ];
  
  return amazonDomains.some(domain => url.includes(domain));
}

// Re-check page status (useful when switching tabs)
async function recheckPageStatus() {
  try {
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      await checkPageStatus(tab);
    }
  } catch (error) {
    console.error('Recheck page status error:', error);
  }
}

// UI State Management
function showLoadingState() {
  hideAllStates();
  elements.loading.classList.remove('hidden');
}

function showReadyState() {
  hideAllStates();
  elements.ready.classList.remove('hidden');
}

function showSuccessState() {
  hideAllStates();
  elements.success.classList.remove('hidden');
}

function showNotAmazonPage() {
  hideAllStates();
  elements.notAmazon.classList.remove('hidden');
}

function showError(message) {
  hideAllStates();
  const errorDiv = document.getElementById('error');
  const errorMessage = document.getElementById('error-message');
  errorMessage.textContent = message;
  errorDiv.classList.remove('hidden');
  showNotification(message, 'error');
}

function hideAllStates() {
  const states = ['loading', 'ready', 'success', 'error', 'not-amazon'];
  states.forEach(state => {
    const element = document.getElementById(state);
    if (element) element.classList.add('hidden');
  });
}

// Check bulk extraction compatibility
function checkBulkCompatibility() {
  if (currentPageInfo && currentPageInfo.isCategoryPage) {
    elements.startBulk.disabled = false;
    elements.startBulk.textContent = 'Start Bulk Extraction';
    // Update products found display
    elements.productsFound.textContent = `${currentPageInfo.productCount || 0} products found`;
  } else {
    elements.startBulk.disabled = true;
    elements.startBulk.textContent = 'Navigate to category page';
    elements.productsFound.textContent = '0 products found';
  }
}

// Event listeners setup
function setupEventListeners() {
  // Single product extraction
  elements.extractBtn.addEventListener('click', handleSingleExtraction);
  
  // Bulk extraction controls
  elements.startBulk.addEventListener('click', handleStartBulkExtraction);
  elements.pauseBulk.addEventListener('click', handlePauseBulkExtraction);
  elements.resumeBulk.addEventListener('click', handleResumeBulkExtraction);
  elements.stopBulk.addEventListener('click', handleStopBulkExtraction);
  
  // Single product export buttons
  elements.viewData.addEventListener('click', () => showDataModal(singleExtractionData));
  elements.copyJson.addEventListener('click', () => handleExport('json', 'copy', false));
  elements.downloadCsv.addEventListener('click', () => handleExport('csv', 'download', false));
  elements.downloadExcel.addEventListener('click', () => handleExport('excel', 'download', false));
  elements.downloadJson.addEventListener('click', () => handleExport('json', 'download', false));
  
  // Bulk export buttons
  elements.bulkViewData.addEventListener('click', () => showDataModal(bulkExtractionData));
  elements.bulkCopyJson.addEventListener('click', () => handleExport('json', 'copy', true));
  elements.bulkDownloadCsv.addEventListener('click', () => handleExport('csv', 'download', true));
  elements.bulkDownloadExcel.addEventListener('click', () => handleExport('excel', 'download', true));
  elements.bulkDownloadJson.addEventListener('click', () => handleExport('json', 'download', true));
  
  // Modal buttons
  elements.modalCopy.addEventListener('click', handleModalCopy);
  elements.modalDownload.addEventListener('click', handleModalDownload);
}

// Single product extraction
async function handleSingleExtraction() {
  try {
    showLoadingState();
    
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    const response = await extensionAPI.tabs.sendMessage(tab.id, {
      action: 'extractSingleProduct',
      options: {
        mode: elements.scrapingMode.value,
        affiliateTag: elements.affiliateTag.value,
        includeAffiliateDetailed: elements.includeAffiliateDetailed.checked
      }
    });
    
    if (response && response.success) {
      singleExtractionData = response.data;
      showSuccessState();
      showNotification('Product data extracted successfully!', 'success');
    } else {
      showError(response?.error || 'Failed to extract product data');
    }
    
  } catch (error) {
    console.error('Single extraction error:', error);
    showError('Failed to extract product data');
  }
}

// Bulk extraction handlers
async function handleStartBulkExtraction() {
  try {
    const quantity = getSelectedQuantity();
    const mode = elements.scrapingMode.value;
    const delay = parseInt(elements.delaySelect.value);
    const affiliateTag = elements.affiliateTag.value;
    const includeAffiliateDetailed = elements.includeAffiliateDetailed.checked;
    
    showBulkProgress();
    isExtracting = true;
    
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    
    // Start bulk extraction
    await extensionAPI.tabs.sendMessage(tab.id, {
      action: 'startBulkScraping',
      options: { quantity, mode, delay, affiliateTag, includeAffiliateDetailed }
    });
    
  } catch (error) {
    console.error('Bulk extraction error:', error);
    showError('Failed to start bulk extraction');
    hideBulkProgress();
  }
}

async function handlePauseBulkExtraction() {
  try {
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    await extensionAPI.tabs.sendMessage(tab.id, { action: 'pauseBulkExtraction' });
    
    elements.pauseBulk.classList.add('hidden');
    elements.resumeBulk.classList.remove('hidden');
    showNotification('Bulk extraction paused.', 'info');
  } catch (error) {
    console.error('Pause error:', error);
  }
}

async function handleResumeBulkExtraction() {
  try {
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    await extensionAPI.tabs.sendMessage(tab.id, { action: 'resumeBulkExtraction' });
    
    elements.resumeBulk.classList.add('hidden');
    elements.pauseBulk.classList.remove('hidden');
    showNotification('Bulk extraction resumed.', 'info');
  } catch (error) {
    console.error('Resume error:', error);
  }
}

async function handleStopBulkExtraction() {
  try {
    const [tab] = await extensionAPI.tabs.query({ active: true, currentWindow: true });
    await extensionAPI.tabs.sendMessage(tab.id, { action: 'stopBulkExtraction' });
    
    hideBulkProgress();
    isExtracting = false;
    showNotification('Bulk extraction stopped.', 'info');
  } catch (error) {
    console.error('Stop error:', error);
  }
}

// Get selected quantity
function getSelectedQuantity() {
  if (elements.quantitySelect.value === 'custom') {
    const customValue = parseInt(elements.customQuantity.value) || 10;
    return Math.min(customValue, 100); // Enforce 100 product limit
  }
  return parseInt(elements.quantitySelect.value);
}

// Show/hide bulk progress
function showBulkProgress() {
  elements.bulkProgress.classList.remove('hidden');
  elements.startBulk.classList.add('hidden');
  elements.controlButtons.classList.remove('hidden');
}

function hideBulkProgress() {
  elements.bulkProgress.classList.add('hidden');
  elements.startBulk.classList.remove('hidden');
  elements.controlButtons.classList.add('hidden');
  elements.bulkExport.classList.add('hidden');
}

// Update progress
function updateProgress(data) {
  const { current, total, successful, failed, currentProduct } = data;
  const percentage = Math.round((current / total) * 100);
  
  elements.progressFill.style.width = `${percentage}%`;
  elements.progressPercentage.textContent = `${percentage}%`;
  elements.progressText.textContent = `Processing ${current} of ${total}`;
  elements.currentProduct.textContent = currentProduct || '-';
  elements.successfulCount.textContent = successful;
  elements.failedCount.textContent = failed;
}

// Show data in modal
function showDataModal(data) {
  if (!data) return;
  
  elements.dataDisplay.textContent = JSON.stringify(data, null, 2);
  elements.dataModal.classList.remove('hidden');
}

// Modal copy functionality
async function handleModalCopy() {
  try {
    const data = elements.dataDisplay.textContent;
    await navigator.clipboard.writeText(data);
    showNotification('Data copied to clipboard!', 'success');
  } catch (error) {
    console.error('Copy error:', error);
    showNotification('Failed to copy data', 'error');
  }
}

// Modal download functionality
function handleModalDownload() {
  try {
    const data = elements.dataDisplay.textContent;
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    extensionAPI.downloads.download({
      url: url,
      filename: `amazon-data-${new Date().toISOString().split('T')[0]}.json`
    });
  } catch (error) {
    console.error('Download error:', error);
    showNotification('Failed to download data', 'error');
  }
}

// Export handlers
async function handleExport(format, action, isBulk) {
  try {
    const data = isBulk ? bulkExtractionData : [singleExtractionData];
    if (!data || (Array.isArray(data) && data.length === 0)) {
      showNotification('No data to export', 'error');
      return;
    }
    
    if (action === 'copy') {
      await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      showNotification('Data copied to clipboard!', 'success');
    } else {
      downloadData(data, format, isBulk ? 'amazon-bulk-products' : 'amazon-product');
    }
  } catch (error) {
    console.error('Export error:', error);
    showNotification('Export failed', 'error');
  }
}

// Download data in specified format
function downloadData(data, format, filename) {
  let content, mimeType, extension;
  
  switch (format) {
    case 'json':
      content = JSON.stringify(data, null, 2);
      mimeType = 'application/json';
      extension = 'json';
      break;
    case 'csv':
      content = convertToCSV(data);
      mimeType = 'text/csv';
      extension = 'csv';
      break;
    case 'excel':
      content = convertToCSV(data);
      mimeType = 'application/vnd.ms-excel';
      extension = 'xls';
      break;
  }
  
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  
  extensionAPI.downloads.download({
    url: url,
    filename: `${filename}-${new Date().toISOString().split('T')[0]}.${extension}`
  });
}

// Convert data to CSV
function convertToCSV(data) {
  if (!Array.isArray(data) || data.length === 0) return '';
  
  const headers = Object.keys(data[0]);
  const csvRows = [headers.join(',')];
  
  for (const item of data) {
    const values = headers.map(header => {
      const value = item[header] || '';
      return `"${value.toString().replace(/"/g, '""')}"`;
    });
    csvRows.push(values.join(','));
  }
  
  return csvRows.join('\n');
}

// Show notification
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.classList.add('notification-toast');
  notification.textContent = message;
  
  if (type === 'success') {
    notification.style.backgroundColor = '#27ae60';
  } else if (type === 'error') {
    notification.style.backgroundColor = '#c0392b';
  } else {
    notification.style.backgroundColor = '#3498db';
  }

  document.body.appendChild(notification);
  setTimeout(() => {
    notification.classList.add('show');
  }, 10);
  
  setTimeout(() => {
    notification.classList.remove('show');
    notification.addEventListener('transitionend', () => notification.remove());
  }, 3000);
}

// Message listener for background updates
extensionAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'bulkProgress':
      updateProgress(message.data);
      break;
    case 'bulkComplete':
      bulkExtractionData = message.data;
      hideBulkProgress();
      elements.bulkExport.classList.remove('hidden');
      isExtracting = false;
      showNotification('Bulk extraction completed!', 'success');
      break;
    case 'bulkError':
      showError(message.error);
      hideBulkProgress();
      isExtracting = false;
      break;
  }
});

console.log('AMZ Extractor popup script initialized');